import numpy as np
from nptyping import NDArray, Shape, Float

a = [[151.73480809, -42.92307428], [302.57618449, -44.7353478 ]]
print(f"a = {a}")
print(f"type of a = {type(a)}")

b = np.asarray(a, dtype = float)
b = np.array([1, 2, 3])
print(f"b = {b}")
print(f"type of b = {type(b)}")

def c(arr: NDArray[Shape["Size, Size"], Float]):
    print(arr)

c(b)
