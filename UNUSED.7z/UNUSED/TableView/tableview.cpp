#include "tableview.h"
#include <QVBoxLayout>
#include <QHBoxLayout>

tableView::tableView(QWidget *parent)
    : QWidget(parent)
{
    //create layout
    QVBoxLayout *mainLayout = new QVBoxLayout();
    QHBoxLayout *horLayout_table_rows = new QHBoxLayout;
    QHBoxLayout *horLayout_table_cols = new QHBoxLayout;
    QHBoxLayout* horLayout_select_rows = new QHBoxLayout;
    QHBoxLayout* horLayout_select_cols = new QHBoxLayout;

    // Create input number of row
    tableRow_label = new QLabel(tr("row : "));
    tableRow_edit = new QLineEdit();
    horLayout_table_rows->addWidget(tableRow_label);
    horLayout_table_rows->addWidget(tableRow_edit);

    //create input number of column
    tableCol_label = new QLabel(tr("Column : "));
    tableCol_edit = new QLineEdit();
    horLayout_table_cols->addWidget(tableCol_label);
    horLayout_table_cols->addWidget(tableCol_edit);

    tableRow_edit->setText("4");
    tableCol_edit->setText("2");
    table_apply = new QPushButton(tr("Apply"));
    connect(table_apply, SIGNAL(clicked()), this, SLOT(tableApply_clicked()));

    //create selection in of row and column
    selectRow_label = new QLabel(tr("row : "));
    selectRow_edit = new QLineEdit();
    horLayout_select_rows->addWidget(selectRow_label);
    horLayout_select_rows->addWidget(selectRow_edit);

    //create input number of column
    selectCol_label = new QLabel(tr("Column : "));
    selectCol_edit = new QLineEdit();
    horLayout_select_cols->addWidget(selectCol_label);
    horLayout_select_cols->addWidget(selectCol_edit);

    selectRow_edit->setText("0");
    selectCol_edit->setText("0");
    select_apply = new QPushButton(tr("Apply"));
    connect(select_apply, SIGNAL(clicked()), this, SLOT(selectApply_clicked()));

    //create QTableView
    tblv = new QTableView();
    tblv->setSelectionBehavior(QAbstractItemView::SelectItems );
    tblv->setSelectionMode( QAbstractItemView::ExtendedSelection );

    //setting layout
    mainLayout->addLayout(horLayout_table_rows);
    mainLayout->addLayout(horLayout_table_cols);
    mainLayout->addWidget(table_apply);
    mainLayout->addLayout(horLayout_select_rows);
    mainLayout->addLayout(horLayout_select_cols);
    mainLayout->addWidget(select_apply);
    mainLayout->addWidget(tblv);
    setLayout(mainLayout);

}

void tableView::tableApply_clicked()
{
    //get number of input row and column
    table_nrow = tableRow_edit->text().toInt();
    table_ncol = tableCol_edit->text().toInt();

    //create model
    QStandardItemModel *model = new QStandardItemModel(table_nrow, table_ncol, this );

    //create QTableview Horizontal Header
    for (int r=0; r< table_ncol; r++)
        model->setHorizontalHeaderItem( r, new QStandardItem( QString("Column_ %0" ).arg(r)) );

    //fill model value
    for( int r=0; r< table_nrow; r++ )
    {
        for( int c=0; c< table_ncol; c++)
        {
            QString sstr = "[ " + QString::number(r) + " , " + QString::number(c) + " ]";
            QStandardItem *item = new QStandardItem(QString("Idx ") + sstr);
            model->setItem(r, c, item);
        }
    }

    //set model
    tblv->setModel(model);
}

void tableView::selectApply_clicked()
{
  //get number of input row and column
  select_nrow = selectRow_edit->text().toInt();
  select_ncol = selectCol_edit->text().toInt();
  QModelIndex index = tblv->model()->index(select_nrow, select_ncol);
  QItemSelectionModel::SelectionFlags flags = QItemSelectionModel::ClearAndSelect | QItemSelectionModel::Rows;
  
  tblv->selectionModel()->setCurrentIndex(index, flags);
  tblv->setFocus();

}