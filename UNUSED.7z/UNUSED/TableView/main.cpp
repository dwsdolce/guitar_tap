#include <QApplication>
#include "tableview.h"

int main( int argc, char **argv )
{
    QApplication app( argc, argv );

    tableView tbl;
    tbl.show();

    return app.exec();
}
