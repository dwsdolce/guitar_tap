#ifndef TABLEVIEW_H
#define TABLEVIEW_H

#include <QtGui>
#include <QWidget>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QString>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

class tableView : public QWidget
{
    Q_OBJECT
public:
    tableView(QWidget *parent = 0);

private:
    QTableView *tblv;
    QLabel *tableRow_label, *tableCol_label, *selectRow_label, *selectCol_label;
    QLineEdit *tableRow_edit, *tableCol_edit, *selectRow_edit, *selectCol_edit;
    QPushButton *table_apply, *select_apply;
    int table_nrow, table_ncol, select_nrow, select_ncol;

private slots:
    void tableApply_clicked();
    void selectApply_clicked();
};

#endif // TABLEVIEW_H
