import sys, os, csv
from PyQt6 import QtCore, QtWidgets   

class Window(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.tableWidget = QtWidgets.QTableWidget()
        self.buttonOpen = QtWidgets.QPushButton('Open')
        self.buttonOpen.clicked.connect(self.handleOpen)
        self.buttonSave = QtWidgets.QPushButton('Save')
        self.buttonSave.clicked.connect(self.handleSave)
        layout = QtWidgets.QGridLayout(self)
        layout.addWidget(self.tableWidget, 0, 0, 1, 2)
        layout.addWidget(self.buttonOpen, 1, 0)
        layout.addWidget(self.buttonSave, 1, 1)

    def handleSave(self):
        path, ok = QtWidgets.QFileDialog.getSaveFileName(
            self, 'Save CSV', os.getenv('HOME'), 'CSV(*.csv)')
        if ok:
            columns = range(self.tableWidget.columnCount())
            header = [self.tableWidget.horizontalHeaderItem(column).text()
                      for column in columns]
            with open(path, 'w') as csvfile:
                writer = csv.writer(
                    csvfile, dialect='excel', lineterminator='\n')
                writer.writerow(header)
                for row in range(self.tableWidget.rowCount()):
                    writer.writerow(
                        self.tableWidget.item(row, column).text()
                        for column in columns)

    def handleOpen(self):
        path, ok = QtWidgets.QFileDialog.getOpenFileName(
            self, 'Open CSV', os.getenv('HOME'), 'CSV(*.csv)')
        if ok:
            self.tableWidget.clear()
            with open(path) as csvfile:
                reader = csv.reader(csvfile)
                header = next(reader)
                self.tableWidget.setColumnCount(len(header))
                self.tableWidget.setHorizontalHeaderLabels(header)
                for row, values in enumerate(reader):
                    self.tableWidget.insertRow(row)
                    for column, value in enumerate(values):
                        self.tableWidget.setItem(
                            row, column, QtWidgets.QTableWidgetItem(value))

if __name__ == '__main__':

    app = QtWidgets.QApplication(sys.argv)
    window = Window()
    window.setWindowTitle('Test')
    window.setGeometry(600, 100, 460, 280)
    window.show()
    sys.exit(app.exec())
