# From https://stackoverflow.com/questions/40126176/fast-live-plotting-in-matplotlib-pyplot
import sys
import time
from PyQt6 import QtCore, QtWidgets
import numpy as np
#import pyqtgraph as pg
from matplotlib import pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg

class drawPlot(FigureCanvasQTAgg):
    def __init__(self):
        self.fig = plt.figure(figsize = (5,3))
        super().__init__(self.fig)

        self.fft_axes = self.fig.subplots()
        self.line, = self.fft_axes.plot([], [], lw=1)


class App(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super(App, self).__init__(parent)

        #### Create Gui Elements ###########
        self.mainbox = QtWidgets.QWidget()
        self.setCentralWidget(self.mainbox)
        self.mainbox.setLayout(QtWidgets.QVBoxLayout())

        
        self.canvas = drawPlot()
        self.mainbox.layout().addWidget(self.canvas)
        
        #self.canvas = pg.GraphicsLayoutWidget()
        #self.mainbox.layout().addWidget(self.canvas)

        self.label = QtWidgets.QLabel()
        self.mainbox.layout().addWidget(self.label)

        #self.view = self.canvas.addViewBox()
        #self.view.setAspectLocked(True)
        #self.view.setRange(QtCore.QRectF(0,0, 100, 100))

        #  image plot
        #self.img = pg.ImageItem(border='w')
        #self.view.addItem(self.img)

        #self.canvas.nextRow()
        #  line plot
        #self.otherplot = self.canvas.addPlot()
        #self.h2 = self.otherplot.plot(pen='y')


        #### Set Data  #####################

        print("DEBUG: set data")
        self.x = np.linspace(0,50., num=100)
        print(f'DEBUG: x = {self.x}')
        self.x_axis = np.arange(0,100)
        print(f'DEBUG: x_axis = {self.x_axis}')
        self.canvas.line.set_xdata(self.x_axis)
        #self.X,self.Y = np.meshgrid(self.x,self.x)
        self.canvas.fft_axes.set_xlim(0, 100)
        self.canvas.fft_axes.set_ylim(-1, 1)

        self.counter = 0
        self.fps = 0.
        self.lastupdate = time.time()

        #### Start  #####################
        print("DEBUG: starting _data")
        self._update()

    def _update(self):

        #self.data = np.sin(self.X/3.+self.counter/9.)*np.cos(self.Y/3.+self.counter/9.)
        self.ydata = np.sin(self.x/3.+ self.counter/9.)

        #self.img.setImage(self.data)
        #self.h2.setData(self.ydata)
        self.canvas.line.set_ydata(self.ydata)
        self.canvas.draw()

        now = time.time()
        dt = (now-self.lastupdate)
        if dt <= 0:
            dt = 0.000000000001
        fps2 = 1.0 / dt
        self.lastupdate = now
        self.fps = self.fps * 0.9 + fps2 * 0.1
        tx = 'Mean Frame Rate:  {fps:.3f} FPS'.format(fps=self.fps )
        self.label.setText(tx)

        QtCore.QTimer.singleShot(1, self._update)
        self.counter += 1


if __name__ == '__main__':

    app = QtWidgets.QApplication(sys.argv)
    thisapp = App()
    thisapp.show()
    sys.exit(app.exec())
