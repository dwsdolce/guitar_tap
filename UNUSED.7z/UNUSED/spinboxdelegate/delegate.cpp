// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

/*
    delegate.cpp

    A delegate that allows the user to change integer values from the model
    using a spin box widget.
*/

#include "delegate.h"

#include <QPushButton>
#include <QEvent>
#include <iostream>
using namespace std;

PushButtonDelegate::PushButtonDelegate(QObject* parent)
  : QStyledItemDelegate(parent)
{
  this->enable = true;
}

QWidget* PushButtonDelegate::createEditor(QWidget* parent,
  const QStyleOptionViewItem&/* option */,
  const QModelIndex&/* index */) const
{
  QPushButton* editor = new QPushButton("off", parent);
  editor->setCheckable(true);
  editor->setChecked(false);

  return editor;
}

void PushButtonDelegate::setEditorData(QWidget* editor,
  const QModelIndex& index) const
{
  QString value = index.model()->data(index, Qt::EditRole).toString();

  QPushButton* pushButton = static_cast<QPushButton*>(editor);
  pushButton->setText(value);
}

void PushButtonDelegate::setModelData(QWidget* editor, QAbstractItemModel* model,
  const QModelIndex& index) const
{
  QPushButton* pushButton = static_cast<QPushButton*>(editor);
  QString value = pushButton->text();

  model->setData(index, value, Qt::EditRole);
}

void PushButtonDelegate::updateEditorGeometry(QWidget* editor,
  const QStyleOptionViewItem& option,
  const QModelIndex&/* index */) const
{
  editor->setGeometry(option.rect);
}

bool PushButtonDelegate::eventFilter(QObject* obj, QEvent* event) 
{
  qDebug() << event->type();
  QPushButton* pushButton = static_cast<QPushButton*>(obj);
  if (this->enable) {
    pushButton->setDisabled(false);
    return false;
  } else {
    pushButton->setDisabled(true);
  }
  return false;
  //if (event->type() == QEvent::Paint) {
  //  return false;
  //}
  //return true;
}
