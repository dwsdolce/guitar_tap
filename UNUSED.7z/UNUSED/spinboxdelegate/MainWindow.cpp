#include "MainWindow.h"
#include "delegate.h"
#include <QHeaderView>
#include <QStandardItemModel>
#include <QTableView>
#include <QVBoxLayout>
#include <QPushButton>
#include <iostream>
using namespace std;

void MainWindow::btnClicked(bool checked)
{
  cout << "Clicked = " << checked;
  this->delegate->enable = checked;
}

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent)
{
  QWidget* centralWidget = new QWidget(this);
  setWindowTitle("Radio Button Delegate");
  setCentralWidget(centralWidget);

  QVBoxLayout* mainLayout = new QVBoxLayout(centralWidget);

  QStandardItemModel *model = new QStandardItemModel(4, 2);
  QTableView *tableView = new QTableView();
  tableView->setModel(model);

  this->delegate = new PushButtonDelegate;
  tableView->setItemDelegate(delegate);

  tableView->horizontalHeader()->setStretchLastSection(true);

  for (int row = 0; row < 4; ++row) {
    for (int column = 0; column < 2; ++column) {
      QModelIndex index = model->index(row, column, QModelIndex());
      model->setData(index, QVariant((row + 1) * (column + 1)).toString());
      tableView->openPersistentEditor(model->index(row, column));
    }
  }

  mainLayout->addWidget(tableView);

  QPushButton* btn = new QPushButton();
  btn->setText("Push Me");
  btn->setCheckable(true);
  btn->setChecked(false);

  QObject::connect(btn, &QPushButton::clicked, this, &MainWindow::btnClicked);

  mainLayout->addWidget(btn);

}