#pragma once

#include <QtWidgets>
#include "delegate.h"

class MainWindow : public QMainWindow
{
public:
  MainWindow(QWidget* parent = nullptr);
  void btnClicked(bool checked);
  PushButtonDelegate* delegate;
};

