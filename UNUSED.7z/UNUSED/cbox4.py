import sys
from PyQt5.QtCore import (Qt, QAbstractTableModel, pyqtSlot)
from PyQt5.QtWidgets import (QLabel, QTextEdit, QApplication,
                             QStyledItemDelegate, QComboBox, QMainWindow, 
                             QTableView, QFormLayout, QPushButton, QWidget,
                             QHBoxLayout, QCheckBox)
import copy


class ComboDelegate(QStyledItemDelegate):
    def __init__(self, parent, items):
        self.items = items
        QStyledItemDelegate.__init__(self, parent)

    def createEditor(self, parent, option, index):
        print("createEditor")
        self.editor = QComboBox(parent)

        self.editor.addItems(self.items)
        self.editor.currentIndexChanged.connect(self.currentIndexChanged)

        return self.editor

    def setEditorData(self, editor, index):
        editor.blockSignals(True) # block signals that are not caused by the user

        value = index.data(Qt.DisplayRole)
        print(f"setEditorData: {value}")
        print(f"setEditorData: index = {index.row()}, {index.column()}")

        num = self.items.index(value)
        editor.setCurrentIndex(num)

        editor.blockSignals(False)

    def setModelData(self, editor, model, index):
        print(f"setModelData: index = {index.row()}, {index.column()}")
        model.setData(index, editor.currentText())
        
    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)
        
    @pyqtSlot()
    def currentIndexChanged(self):
        self.commitData.emit(self.sender())
 
        
class tableModel(QAbstractTableModel):
    def __init__(self, table_data = [['', '', '', '', '']]):
        QAbstractTableModel.__init__(self)
        self.table_data = table_data
        self.no_columns = 5
        
    def addRow(self, rowNbr, rowData):
        if rowNbr == -1:
            self.table_data.append(rowData)
        else:
            self.table_data.insert(rowNbr, rowData)
        self.layoutChanged.emit()
        
    def deleteRow(self, rowNbr):
        self.table_data.pop(rowNbr)
        
    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        
        value = self.table_data[index.row()][index.column()]
        
        if role == Qt.EditRole:
            return value
        
        if role == Qt.DisplayRole:    
            if isinstance(value, float):
                # Render float to 2 dp
                return "%.2f" % value
            else:
                return value
        
        if role == Qt.TextAlignmentRole:
            if index.column() in [0, 1, 2]:
                return Qt.AlignVCenter + Qt.AlignLeft
            else:
                return Qt.AlignVCenter + Qt.AlignRight

    def rowCount(self, index):
        return len(self.table_data)

    def columnCount(self, index):
        return self.no_columns

    def headerData(self, section, orientation, role):
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            return ("Type", "ID", "Location", "Offset T [\xB0C]", 
                    "Offset RH [%]")[section]
        else:
            return "{}".format(section)
     
    def setData(self, index, value, role=Qt.EditRole):
        if index.isValid():
            print(f"setData: index is valid: {index.row()}, {index.column()}")
            self.table_data[index.row()][index.column()] = value
            self.dataChanged.emit(index, index, [Qt.DisplayRole])
            return True
        else:
            print("setData: index is NOT valid")
            return False
            
    def flags(self, index):
        return Qt.ItemIsEditable | Qt.ItemIsEnabled | Qt.ItemIsSelectable
    

class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        fbox = QFormLayout()
        hbox = QHBoxLayout()
        self.table = QTableView()
        self.label = QLabel('Current table data as python list')
        self.tedit = QTextEdit()
        self.applyFixCheckBox = QCheckBox('Apply fix (close and reopen '
                                          + 'persistent editor. To be checked '
                                          + 'right after program start in '
                                          + 'this example)')
        fbox.addRow(self.table)
        self.addRowBtn = QPushButton('Add row')
        self.deleteRowBtn = QPushButton("Delete row")
        self.addRowBtn.clicked.connect(self.add_row2table)
        self.deleteRowBtn.clicked.connect(self.delete_row_from_table)
        hbox.addWidget(self.addRowBtn)
        hbox.addWidget(self.deleteRowBtn)
        fbox.addRow(hbox)
        fbox.addRow(self.label)
        fbox.addRow(self.tedit)
        fbox.addRow(self.applyFixCheckBox)
        self.centralWidget().setLayout(fbox)
        

        #data = [['Option2', 'Teststring', 'Testlocation', 1, 2],
        #        ['Option1', 'Teststring', 'Testlocation', 0, 0]]
        data = []

        self.model = tableModel(data)
        self.table.setModel(self.model)
        self.model.dataChanged.connect(self.tableChanged)
        self.resize(600,400)
        self.lastTableData = []
        self.tableChanged()
        #self.setComboBoxes()
        self.table.setItemDelegateForColumn(0, ComboDelegate(self, 
                                            ["",
                                             "Option1", 
                                             "Option2",
                                             "Option3"]))
        self.table.setEditTriggers(QTableView.EditTrigger.AllEditTriggers)
        
        
    def tableChanged(self):
        if self.model.table_data != self.lastTableData:
            self.tedit.setText(str(self.model.table_data))
            self.table.model().layoutChanged.emit()
            self.lastTableData = copy.deepcopy(self.model.table_data)       
            
    # def setComboBoxes(self):
    #     print("setComboBoxes")
    #     self.table.setItemDelegateForColumn(0, ComboDelegate(self, 
    #                                         ["",
    #                                          "Option1", 
    #                                          "Option2",
    #                                          "Option3"]))
    #     for row in range(0, self.model.rowCount(0)):
    #         print(f"setComboBoxes: openEditor {row}")
    #         self.table.openPersistentEditor(self.model.index(row, 0))
               
    def add_row2table(self):
        #if self.applyFixCheckBox.isChecked():
            # have to actively close the persistent editor, otherwise when reopening
            # an editor it is drawn ontop of the old one
            #for row in range(0, self.model.rowCount(0)):
            #    self.table.closePersistentEditor(self.model.index(row, 0))
            
        index = sorted(self.table.selectionModel().selectedRows())
        if index != []:
            self.model.addRow(index[0].row(), ['Option1', '', '', '', ''])
        else: # add row at the end
            self.model.addRow(-1, ['Option1', '', '', '', ''])
        self.tableChanged()
        #self.setComboBoxes()

    def delete_row_from_table(self):
        indexes = sorted(self.table.selectionModel().selectedRows())
        if indexes != []:
            #if self.applyFixCheckBox.isChecked():
                # have to actively close the persistent editor, otherwise when
                # reopening an editor it is drawn ontop of the old one
            #    for row in range(0, self.model.rowCount(0)):
            #        self.table.closePersistentEditor(self.model.index(row, 0))
                
            ind = [elem.row() for elem in indexes]
            ind.reverse()
            for i in ind:
                self.model.deleteRow(i)
            self.tableChanged()   
            #self.setComboBoxes()

    def closeEvent(self,event):
        QApplication.quit()

 
if __name__ == '__main__':   
    app = QApplication.instance()
    # prevent kernel crash at every second run of the program due to bug 
    # in iPython 
    if app is None:
        app = QApplication(sys.argv)
    
    main = Main()
    main.show()
    main.raise_()
    app.exec_()
    
